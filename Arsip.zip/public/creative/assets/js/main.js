$(function() {

	// $('#exampleModalCenter').modal();

	
})