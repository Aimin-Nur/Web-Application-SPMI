
</section>

<div class="container-fluid">
    <div class="col-lg-12">
        <form method="post" action="<?php echo e(route('profile.update')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>
            <div class="mt-3">
                <label for="name" class="form-label"><?php echo e(__('Name')); ?></label>
                <input id="name" name="name" type="text" class="form-control" value="<?php echo e(old('name', $user->name)); ?>" required autofocus autocomplete="name">
            </div>

            <div class="mb-3">
                <label for="email" class="form-label"><?php echo e(__('Email')); ?></label>
                <input id="email" name="email" type="email" class="form-control" value="<?php echo e(old('email', $user->email)); ?>" required autocomplete="username">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php if($user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail && ! $user->hasVerifiedEmail()): ?>
                    <div class="mt-2 text-gray-800">
                        <?php echo e(__('Your email address is unverified.')); ?>

                        <button form="send-verification" type="submit" class="btn btn-link">
                            <?php echo e(__('Click here to re-send the verification email.')); ?>

                        </button>
                        <?php if(session('status') === 'verification-link-sent'): ?>
                            <p class="mt-2 text-success"><?php echo e(__('A new verification link has been sent to your email address.')); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div>
                <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                <?php if(session('status') === 'profile-updated'): ?>
                    <p x-data="{ show: true }" x-show="show" x-transition x-init="setTimeout(() => show = false, 2000)" class="text-success"><?php echo e(__('Saved.')); ?></p>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>
<?php /**PATH /Users/muhaiminnur/Desktop/repo/spmi9/resources/views/profile/partials/update-profile-information-form.blade.php ENDPATH**/ ?>