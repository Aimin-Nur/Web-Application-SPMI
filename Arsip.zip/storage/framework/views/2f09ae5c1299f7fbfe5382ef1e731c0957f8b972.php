<?php echo $__env->make('layouts.header-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.navbar-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if($getData->isEmpty()): ?>
<div class="container-fluid py-4 mb-auto">
    <div class="page-body">
        <div class="row">
            <div class="col-lg-12 d-flex flex-column justify-content-center text-center">
                <div class="empty">
                <div class="img-fluid"><img src="<?php echo e(asset('creative')); ?>/assets/img/empty.png" alt="RTM Kosong" width="420px">
                </div>
                <p class="empty-title text-bold">Belum Ada Data Laporan Audit</p>
                <p class="empty-subtitle text-secondary">
                    Try adjusting your search or filter to find what you're looking for.
                  </p>
                </div>
            </div>
        </div>
        </div>
    </div>
</div>
<?php else: ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('superadmin.laporan-table')->html();
} elseif ($_instance->childHasBeenRendered('YeHy6M5')) {
    $componentId = $_instance->getRenderedChildComponentId('YeHy6M5');
    $componentTag = $_instance->getRenderedChildComponentTagName('YeHy6M5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YeHy6M5');
} else {
    $response = \Livewire\Livewire::mount('superadmin.laporan-table');
    $html = $response->html();
    $_instance->logRenderedChild('YeHy6M5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php endif; ?>









<?php echo $__env->make('layouts.footer-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.script-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Users/muhaiminnur/Desktop/repo/spmi9/resources/views/superadmin/viewLaporan.blade.php ENDPATH**/ ?>