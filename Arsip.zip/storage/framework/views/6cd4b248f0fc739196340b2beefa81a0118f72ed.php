<?php echo $__env->make('layouts.header-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.navbar-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid py-4">
    <div class="col-lg-12">
        <form class="card" action="/sendDokumen" method="post">
            <?php echo csrf_field(); ?>
          <div class="card-header">
            <h5 class="card-title">Data Dokumen</h5>
          </div>
          <div class="card-body">
            <div class="mb-3 row">
              <label class="col-3 col-form-label required">Nama Dokumen</label>
              <div class="col">
                <input type="text" class="form-control" name="field_judul" aria-describedby="emailHelp" placeholder="Sistem Informasi Akademik">
                <small class="form-hint">We'll never share your email with anyone else.</small>
              </div>
            </div>
            <div class="mb-3 row">
              <label class="col-3 col-form-label required">Tautan Dokumen</label>
              <div class="col">
                <input name="field_tautan" type="text" class="form-control" placeholder="https://docs.google.com/spreadsheets/d/1cvO-luocDUgA9vBxjvKtd76ZSWY9WDeIvwAHj0CmQAA/edit?gid=0#gid=0">
                <small class="form-hint">
                  Masukkan Link Spredsheet Dokumen Anda. Pastikan Dokumen Dapat Diakses Oleh Orang Lain
                </small>
              </div>
            </div>
            <div class="mb-3 row">
              <label class="col-3 col-form-label">Lembaga/Biro</label>
              <div class="col">
                <select class="form-select" name="id_lembaga">
                    <option>Pilih Lembaga</option>
                    <?php $__currentLoopData = $getData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_lembaga); ?> - <?php echo e($item->user->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <small class="form-hint">
                    Pilih lembaga atau instansi yang sesuai dengan dokumen yang Anda tambahkan.
                </small>
              </div>
            </div>
            <div class="mb-3 row">
                <label class="col-3 col-form-label">Durasi Pengerjaan</label>
                <div class="col">
                  <input class="form-control" type="date" name="field_durasi" placeholder="3 Hari">
                  <small class="form-hint">
                      Tentukan Durasi Pengerjaan Dokumen Lembaga.
                  </small>
                </div>
              </div>

          </div>
          <div class="card-footer text-end">
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </form>
    </div>
</div>



<?php echo $__env->make('layouts.footer-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.script-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Users/muhaiminnur/Desktop/repo/spmi9/resources/views/admin/formDokumen.blade.php ENDPATH**/ ?>