<section class="container mt-5">
    <div class="card">
        <div class="card-header">
            <h2 class="text-lg font-medium text-gray-900">
                <?php echo e(__('Update Password')); ?>

            </h2>
            <p class="mt-1 text-sm text-gray-600">
                <?php echo e(__('Ensure your account is using a long, random password to stay secure.')); ?>

            </p>
        </div>
        <div class="card-body">
            <form method="post" action="<?php echo e(route('password.update')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>

                <div class="form-group">
                    <label for="current_password"><?php echo e(__('Current Password')); ?></label>
                    <input id="current_password" name="current_password" type="password" class="form-control" autocomplete="current-password">
                    <?php if($errors->updatePassword->get('current_password')): ?>
                        <small class="text-danger"><?php echo e($errors->updatePassword->get('current_password')[0]); ?></small>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="password"><?php echo e(__('New Password')); ?></label>
                    <input id="password" name="password" type="password" class="form-control" autocomplete="new-password">
                    <?php if($errors->updatePassword->get('password')): ?>
                        <small class="text-danger"><?php echo e($errors->updatePassword->get('password')[0]); ?></small>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="password_confirmation"><?php echo e(__('Confirm Password')); ?></label>
                    <input id="password_confirmation" name="password_confirmation" type="password" class="form-control" autocomplete="new-password">
                    <?php if($errors->updatePassword->get('password_confirmation')): ?>
                        <small class="text-danger"><?php echo e($errors->updatePassword->get('password_confirmation')[0]); ?></small>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                    <?php if(session('status') === 'password-updated'): ?>
                        <p class="text-success mt-2"><?php echo e(__('Saved.')); ?></p>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</section>
<?php /**PATH /Users/muhaiminnur/Desktop/repo/spmi9/resources/views/profile/partials/update-password-form.blade.php ENDPATH**/ ?>