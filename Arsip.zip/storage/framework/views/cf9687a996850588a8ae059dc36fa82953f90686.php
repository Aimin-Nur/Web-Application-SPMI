<?php echo $__env->make('layouts.header-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.navbar-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="container-fluid">
    <div class="page-header min-height-300 border-radius-xl mt-4" style="background-image: url('<?php echo e(asset('creative')); ?>/assets/img/curved-images/curved0.jpg'); background-position-y: 50%;">
      <span class="mask bg-gradient-primary opacity-6"></span>
    </div>
    <div class="card card-body blur shadow-blur mx-4 mt-n6 overflow-hidden">
      <div class="row gx-4">
        <div class="col-auto my-auto">
          <div class="h-100">
            <h5 class="mb-1">
              Temuan Audit Lembaga
            </h5>
            <p class="mb-0 font-weight-bold text-xs">
              SPMI Kalla Institute
            </p>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 my-sm-auto ms-sm-auto me-sm-0 mx-auto mt-3">
          <div class="nav-wrapper position-relative end-0">
            <ul class="nav nav-pills nav-fill p-1 bg-transparent" role="tablist" id="pills-tab">
                <li class="nav-item" role="presentation">
                  <a class="nav-link mb-0 px-0 py-1 active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">
                    <svg class="text-dark" width="16px" height="16px" viewBox="0 0 42 42" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                      <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                        <g transform="translate(-2319.000000, -291.000000)" fill="#FFFFFF" fill-rule="nonzero">
                          <g transform="translate(1716.000000, 291.000000)">
                            <g transform="translate(603.000000, 0.000000)">
                              <path class="color-background" d="M22.7597136,19.3090182 L38.8987031,11.2395234 C39.3926816,10.9925342 39.592906,10.3918611 39.3459167,9.89788265 C39.249157,9.70436312 39.0922432,9.5474453 38.8987261,9.45068056 L20.2741875,0.1378125 L20.2741875,0.1378125 C19.905375,-0.04725 19.469625,-0.04725 19.0995,0.1378125 L3.1011696,8.13815822 C2.60720568,8.38517662 2.40701679,8.98586148 2.6540352,9.4798254 C2.75080129,9.67332903 2.90771305,9.83023153 3.10122239,9.9269862 L21.8652864,19.3090182 C22.1468139,19.4497819 22.4781861,19.4497819 22.7597136,19.3090182 Z">
                              </path>
                              <path class="color-background" d="M23.625,22.429159 L23.625,39.8805372 C23.625,40.4328219 24.0727153,40.8805372 24.625,40.8805372 C24.7802551,40.8805372 24.9333778,40.8443874 25.0722402,40.7749511 L41.2741875,32.673375 L41.2741875,32.673375 C41.719125,32.4515625 42,31.9974375 42,31.5 L42,14.241659 C42,13.6893742 41.5522847,13.241659 41,13.241659 C40.8447549,13.241659 40.6916418,13.2778041 40.5527864,13.3472318 L24.1777864,21.5347318 C23.8390024,21.7041238 23.625,22.0503869 23.625,22.429159 Z" opacity="0.7"></path>
                              <path class="color-background" d="M20.4472136,21.5347318 L1.4472136,12.0347318 C0.953235098,11.7877425 0.352562058,11.9879669 0.105572809,12.4819454 C0.0361450918,12.6208008 6.47121774e-16,12.7739139 0,12.929159 L0,30.1875 L0,30.1875 C0,30.6849375 0.280875,31.1390625 0.7258125,31.3621875 L19.5528096,40.7750766 C20.0467945,41.0220531 20.6474623,40.8218132 20.8944388,40.3278283 C20.963859,40.1889789 21,40.0358742 21,39.8806379 L21,22.429159 C21,22.0503869 20.7859976,21.7041238 20.4472136,21.5347318 Z" opacity="0.7"></path>
                            </g>
                          </g>
                        </g>
                      </g>
                    </svg>
                    <span class="ms-1">Temuan</span>
                  </a>
                </li>
                <li class="nav-item" role="presentation">
                  <a class="nav-link mb-0 px-0 py-1" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">
                    <svg class="text-dark" width="16px" height="16px" viewBox="0 0 40 44" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                      <title>document</title>
                      <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                        <g transform="translate(-1870.000000, -591.000000)" fill="#FFFFFF" fill-rule="nonzero">
                          <g transform="translate(1716.000000, 291.000000)">
                            <g transform="translate(154.000000, 300.000000)">
                              <path class="color-background" d="M40,40 L36.3636364,40 L36.3636364,3.63636364 L5.45454545,3.63636364 L5.45454545,0 L38.1818182,0 C39.1854545,0 40,0.814545455 40,1.81818182 L40,40 Z" opacity="0.603585379"></path>
                              <path class="color-background" d="M30.9090909,7.27272727 L1.81818182,7.27272727 C0.814545455,7.27272727 0,8.08727273 0,9.09090909 L0,41.8181818 C0,42.8218182 0.814545455,43.6363636 1.81818182,43.6363636 L30.9090909,43.6363636 C31.9127273,43.6363636 32.7272727,42.8218182 32.7272727,41.8181818 L32.7272727,9.09090909 C32.7272727,8.08727273 31.9127273,7.27272727 30.9090909,7.27272727 Z M18.1818182,34.5454545 L7.27272727,34.5454545 L7.27272727,30.9090909 L18.1818182,30.9090909 L18.1818182,34.5454545 Z M25.4545455,27.2727273 L7.27272727,27.2727273 L7.27272727,23.6363636 L25.4545455,23.6363636 L25.4545455,27.2727273 Z M25.4545455,20 L7.27272727,20 L7.27272727,16.3636364 L25.4545455,16.3636364 L25.4545455,20 Z">
                              </path>
                            </g>
                          </g>
                        </g>
                      </g>
                    </svg>
                    <span class="ms-1">Riwayat</span>
                  </a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link mb-0 px-0 py-1" id="pills-score-tab" data-bs-toggle="pill" data-bs-target="#pills-score" type="button" role="tab" aria-controls="pills-score" aria-selected="false">
                        <svg class="text-dark" width="16px" height="16px" viewBox="0 0 40 44" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                            <title>document</title>
                            <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                <g transform="translate(-1870.000000, -591.000000)" fill="#FFFFFF" fill-rule="nonzero">
                                    <g transform="translate(1716.000000, 291.000000)">
                                        <g transform="translate(154.000000, 300.000000)">
                                            <path class="color-background" d="M40,40 L36.3636364,40 L36.3636364,3.63636364 L5.45454545,3.63636364 L5.45454545,0 L38.1818182,0 C39.1854545,0 40,0.814545455 40,1.81818182 L40,40 Z" opacity="0.603585379"></path>
                                            <path class="color-background" d="M30.9090909,7.27272727 L1.81818182,7.27272727 C0.814545455,7.27272727 0,8.08727273 0,9.09090909 L0,41.8181818 C0,42.8218182 0.814545455,43.6363636 1.81818182,43.6363636 L30.9090909,43.6363636 C31.9127273,43.6363636 32.7272727,42.8218182 32.7272727,41.8181818 L32.7272727,9.09090909 C32.7272727,8.08727273 31.9127273,7.27272727 30.9090909,7.27272727 Z M18.1818182,34.5454545 L7.27272727,34.5454545 L7.27272727,30.9090909 L18.1818182,30.9090909 L18.1818182,34.5454545 Z M25.4545455,27.2727273 L7.27272727,27.2727273 L7.27272727,23.6363636 L25.4545455,23.6363636 L25.4545455,27.2727273 Z M25.4545455,20 L7.27272727,20 L7.27272727,16.3636364 L25.4545455,16.3636364 L25.4545455,20 Z"></path>
                                        </g>
                                    </g>
                                </g>
                            </g>
                        </svg>
                        <span class="ms-1">Score</span>
                    </a>
                </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
</div>

<div class="tab-content" id="pills-tabContent">
    <!-- Existing tabs content -->
    <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
        <?php if($evaluasi->isEmpty()): ?>
        <div class="container-fluid py-4">
            <div class="page-body">
                <div class="row">
                    <div class="col-lg-12 d-flex flex-column justify-content-center text-center">
                        <div class="empty">
                            <div class="img-fluid"><img src="<?php echo e(asset('creative')); ?>/assets/img/empty.png" alt="RTM Kosong" width="300px"></div>
                            <p class="empty-title text-bold">Tidak Ada Dokumen Yang Menunggu Untuk Diperiksa.</p>
                            <div class="empty-action">
                                <a href="/addTemuan" class="btn btn-primary">
                                    <i class="fas fa-plus"></i>&nbsp;&nbsp;Tambah Temuan Audit
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php else: ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.temuan-table')->html();
} elseif ($_instance->childHasBeenRendered('sJ2hbrf')) {
    $componentId = $_instance->getRenderedChildComponentId('sJ2hbrf');
    $componentTag = $_instance->getRenderedChildComponentTagName('sJ2hbrf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('sJ2hbrf');
} else {
    $response = \Livewire\Livewire::mount('admin.temuan-table');
    $html = $response->html();
    $_instance->logRenderedChild('sJ2hbrf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php endif; ?>
    </div>

    <div class="tab-pane" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
        <?php if($riwayat->isEmpty()): ?>
        <div class="container-fluid py-4">
            <div class="page-body">
                <div class="row">
                    <div class="col-lg-12 d-flex flex-column justify-content-center text-center">
                        <div class="empty">
                            <div class="img-fluid"><img src="<?php echo e(asset('creative')); ?>/assets/img/empty.png" alt="RTM Kosong" width="300px"></div>
                            <p class="empty-title text-bold">Belum Terdapat Riwayat Temuan Audit</p>
                            <div class="empty-action">
                                <a href="/addTemuan" class="btn btn-primary">
                                    <i class="fas fa-plus"></i>&nbsp;&nbsp;Tambah Temuan Audit
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php else: ?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.riwayat-temuan')->html();
} elseif ($_instance->childHasBeenRendered('twUBDDZ')) {
    $componentId = $_instance->getRenderedChildComponentId('twUBDDZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('twUBDDZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('twUBDDZ');
} else {
    $response = \Livewire\Livewire::mount('admin.riwayat-temuan');
    $html = $response->html();
    $_instance->logRenderedChild('twUBDDZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php endif; ?>
    </div>

    <div class="tab-pane" id="pills-score" role="tabpanel" aria-labelledby="pills-score-tab">
        <?php if($skorPerLembaga->isEmpty()): ?>
        <div class="container-fluid py-4">
            <div class="page-body">
                <div class="row">
                    <div class="col-lg-12 d-flex flex-column justify-content-center text-center">
                        <div class="empty">
                            <div class="img-fluid"><img src="<?php echo e(asset('creative')); ?>/assets/img/empty.png" alt="Tidak Ada Skor" width="300px"></div>
                            <p class="empty-title text-bold">Belum Terdapat Skor untuk Lembaga.</p>
                            <div class="empty-action">
                                <a href="/addTemuan" class="btn btn-primary">
                                    <i class="fas fa-plus"></i>&nbsp;&nbsp;Tambah Temuan Audit
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php else: ?>
        <div class="container-fluid py-4">
            <div class="row">
                <div class="col-12">
                    <div class="card mb-4">
                        <div class="card-header pb-0">
                            <h6>Skor Temuan Audit Setiap Lembaga</h6>
                        </div>
                        <div class="card-body px-0 pt-0 pb-2">
                            <div class="table-responsive p-0">
                                <table class="table align-items-center mb-0">
                                    <thead>
                                        <tr>
                                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Lembaga</th>
                                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Total Temuan</th>
                                            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Total Skor</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $skorPerLembaga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex px-2 py-1">
                                                    <div class="d-flex flex-column justify-content-center">
                                                        <h6 class="mb-0 text-sm"><?php echo e($item->lembaga->nama_lembaga); ?></h6>
                                                        <p class="text-xs text-secondary mb-0"><?php echo e($item->lembaga->user->name); ?></p>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="d-flex flex-column justify-content-center ms-4">
                                                    <p class="text-xs font-weight-bold text-secondary mb-0"><?php echo e($item->total_temuan); ?> Temuan</p>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="d-flex flex-column justify-content-center me-5">
                                                    <p class="text-lg font-weight-bold text- ms-5 mb-0"><?php echo e($item->total_score); ?></p>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

</div>

</div>
</div>


<?php $__currentLoopData = $evaluasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="editModalCenter<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content rounded-0">
            <div class="modal-body bg-3">
                <div class="px-3 to-front">
                    <div class="row align-items-center">
                        <div class="col text-right">
                            <a href="#" class="close-btn" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true"><span class="icon-close2"></span></span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="p-4 to-front">
                    <div class="text-center">
                        <div class="logo">
                            <img src="<?php echo e(asset('creative')); ?>/assets/img/send-docs.jpg" alt="img-fluid" class="img-fluid mb-4 w-60">
                        </div>
                        <h4>Edit Status Dokumen</h4>
                        <p class="mb-3 text-sm">Lembaga telah melakukan pengisian kelengkapan dokumen yang telah Anda berikan pada tanggal : <b><?php echo e(\Carbon\Carbon::parse($item->tgl_pengumpulan)->locale('id')->translatedFormat('l, d F Y')); ?></b></p>
                        <form action="/editTemuan/<?php echo e($item->id); ?>" class="mb-4" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                             <div class="form-group">
                                 <select class="form-select status-select" name="status" id="statusSelect<?php echo e($item->id); ?>">
                                     <option value="">Pilih Status Dokumen</option>
                                     <option value="1">Poor</option>
                                     <option value="2">Average</option>
                                     <option value="3">Good</option>
                                     <option value="4">Excellent</option>
                                 </select>
                             </div>
                             <div class="deadline-form" id="Score-form<?php echo e($item->id); ?>" style="display: none;">
                                 <div class="form-group">
                                     <label for="score">Score</label>
                                     <input type="number" class="form-control" id="score<?php echo e($item->id); ?>" name="score" placeholder="0 - 276">
                                 </div>
                             </div>
                            <div class="row">
                                <div class="col-6 mt-4">
                                    <button class="btn btn-secondary btn-block" data-dismiss="modal">Batalkan</button>
                                </div>
                                <div class="col-6 mt-4">
                                     <input type="hidden" name="hidden_score" value="4" id="hiddenScore<?php echo e($item->id); ?>">
                                    <button type="submit" class="btn btn-primary btn-block">Simpan Status</button>
                                </div>
                            </div>
                        </form>
                        <small class="mb-0 cancel"><small><i>Sistem Penjaminan Mutu Internal Kalla Institute</i></small></small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 <script>
     document.addEventListener('DOMContentLoaded', function() {
         const statusSelects = document.querySelectorAll('.status-select');
         const deadlineForms = document.querySelectorAll('.deadline-form');

         statusSelects.forEach((statusSelect, index) => {
             const deadlineForm = deadlineForms[index];
             const hiddenScore = document.getElementById('hiddenScore' + statusSelect.id.replace('statusSelect', ''));
             const scoreInput = document.getElementById('score' + statusSelect.id.replace('statusSelect', ''));

             statusSelect.addEventListener('change', function() {
                 const selectedValue = this.value;
                 if (selectedValue === '1' || selectedValue === '2' || selectedValue === '3' || selectedValue === '4') {
                     deadlineForm.style.display = 'block';
                     hiddenScore.name = '';
                     scoreInput.name = 'score';
                 } else {
                     deadlineForm.style.display = 'none';
                     hiddenScore.name = 'score';
                     scoreInput.name = '';
                     hiddenScore.value = '4'; // kondisi close
                     scoreInput.value = '';
                 }
             });

             if (statusSelect.value === '1' || statusSelect.value === '2') {
                 deadlineForm.style.display = 'block';
                 hiddenScore.name = ''; // Disable hidden score input
                 scoreInput.name = 'score'; // Enable visible score input
             } else {
                 deadlineForm.style.display = 'none';
                 hiddenScore.name = 'score'; // Enable hidden score input
                 scoreInput.name = ''; // Disable visible score input
             }
         });
     });
 </script>

 
 <?php $__currentLoopData = $evaluasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div class="modal fade" id="hapusModalCenter<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"   aria-hidden="true">
   <div class="modal-dialog modal-dialog-centered" role="document">
     <div class="modal-content rounded-0">
         <div class="modal-body bg-3">
         <div class="px-3 to-front">
             <div class="row align-items-center">
             <div class="col text-right">
                 <a href="#" class="close-btn" data-dismiss="modal" aria-label="Close">
                 <span aria-hidden="true"><span class="icon-close2"></span></span>
                 </a>
             </div>
             </div>
         </div>
         <div class="p-4 to-front">
             <div class="text-center">
             <div class="logo">
                 <img src="<?php echo e(asset('creative')); ?>/assets/img/hapus-docs.jpg" alt="img-fluid" class="img-fluid mb-4 w-60">
             </div>
             <h4>Hapus Temuan Audit</h4>
             <p class="mb-3 text-sm">Tindakan ini akan menghapus Temuan Audit <b> "<?php echo e($item->temuan); ?>"</b> secara permanen.</p>
             <form action="/hapusTemuan/<?php echo e($item->id); ?>" class="mb-4" method="POST">
                 <?php echo csrf_field(); ?>
                 <?php echo method_field('DELETE'); ?>
                 <div class="row">
                 <div class="col-6 mt-4">
                     <button class="btn btn-secondary btn-block" data-dismiss="modal">Batalkan</button>
                 </div>
                 <div class="col-6 mt-4">
                     <button type="submit" class="btn btn-primary btn-block">Hapus Dokumen</button>
                 </div>
                 </div>
             </form>
             <small class="mb-0 cancel"><small><i>Sistem Penjaminan Mutu Internal Kalla Institute</i></small></small>
             </div>
         </div>
         </div>
     </div>
   </div>
 </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 
<?php $__currentLoopData = $evaluasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="unsend<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
           <div class="modal-content rounded-0">
               <div class="modal-body bg-3">
                   <div class="px-3 to-front">
                       <div class="row align-items-center">
                           <div class="col text-right">
                               <a href="#" class="close-btn" data-dismiss="modal" aria-label="Close">
                                   <span aria-hidden="true"><span class="icon-close2"></span></span>
                               </a>
                           </div>
                       </div>
                   </div>
                   <div class="p-4 to-front">
                       <div class="text-center">
                           <div class="logo">
                               <img src="<?php echo e(asset('creative')); ?>/assets/img/unsend.png" alt="img-fluid" class="img-fluid mb-4 w-60">
                           </div>
                           <h4>Lembaga Belum Menyelesaikan Dokumen</h4>
                           <p class="mb-3 text-sm">Lembaga Belum Menyelesaikan Dokumen yang Anda Kirimkan. Hubungi Admin Lembaga Untuk Informasi Lebih Lanjut.</p>
                            <div class="col-12 mt-4">
                                <button type="button" aria-label="Close" data-dismiss="modal" class="btn btn-primary btn-block">Oke, Saya Mengerti</button>
                            </div>
                            <small class="mb-0 cancel text-center"><small><i>Sistem Penjaminan Mutu Internal Kalla Institute</i></small></small>
                        </div>
                        </div>
                   </div>
               </div>
           </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo $__env->make('layouts.footer-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.script-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Users/muhaiminnur/Desktop/repo/spmi9/resources/views/admin/evaluasi.blade.php ENDPATH**/ ?>